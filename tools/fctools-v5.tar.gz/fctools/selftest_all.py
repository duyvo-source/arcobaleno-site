#!/usr/bin/env python3
"""Run every instrument's self-test. This is the toolkit's own FC-1.

Each instrument ships with a synthetic case reproducing the defect it was built to find. If one of
these fails, the instrument is broken and any finding it produced is unsafe to hand a client.

    python3 selftest_all.py
"""
import os, subprocess, sys

# Resolve instruments relative to THIS FILE, not the caller's working directory: the toolkit is
# unpacked next to the client's data and run from wherever that happens to be, and a gate that
# only works from one cwd is a gate that gets skipped under time pressure.
HERE = os.path.dirname(os.path.abspath(__file__))

# (script, label, args). Most instruments self-test with --selftest; the out-of-core gate runs
# both engines over the same fixtures and IS the test, so it takes no flag.
TOOLS = [
    ('fc1_reproduce.py',     'FC-1  does it repeat',              ['--selftest']),
    ('fc4_concentration.py', 'FC-4  one row carrying the result',  ['--selftest']),
    ('fc6_episodes.py',      'FC-6  trades versus episodes',       ['--selftest']),
    ('fc8_bootstrap.py',     'FC-8  i.i.d. versus block CI',       ['--selftest']),
    ('fc8_ordering.py',      'FC-8  sort order sensitivity',       ['--selftest']),
    ('selftest_ooc.py',      'RED   streaming engine parity',      ['--rows', '2000000']),
]

def _stack() -> str:
    """The exact stack the checks ran on. Cite this in the report: a finding is only
    reproducible if the reader knows what it was produced with."""
    v = f'python {sys.version.split()[0]}'
    for mod in ('numpy', 'pandas', 'pyarrow', 'duckdb'):
        try:
            v += f' · {mod} {__import__(mod).__version__}'
        except Exception:
            v += f' · {mod} MISSING'
    return v


def main() -> int:
    print(f'  stack: {_stack()}')
    print()
    failed = []
    for script, label, args in TOOLS:
        p = subprocess.run([sys.executable, os.path.join(HERE, script), *args],
                           capture_output=True, text=True, cwd=HERE)
        status = 'PASS' if p.returncode == 0 else 'FAIL'
        print(f'  {status}  {label:<38} ({script})')
        if p.returncode != 0:
            failed.append((script, p.stdout[-600:], p.stderr[-600:]))
    print(f'\n  {len(TOOLS) - len(failed)}/{len(TOOLS)} instruments pass')
    for script, out, err in failed:
        print(f'\n--- {script} ---\n{out}\n{err}')
    return 1 if failed else 0

if __name__ == '__main__':
    sys.exit(main())
