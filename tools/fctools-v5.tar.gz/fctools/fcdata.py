"""Out-of-core column access for the FC instruments.

**Why this exists.** Every other instrument takes a numpy array, which means the whole column has
to be in RAM before the check can start. That is fine for daily bars and impossible for tick or
full order-book data — the exact reason `INTAKE.md` Part B declined RED engagements.

This layer answers the handful of questions the instruments actually ask of a column — how many,
what do they sum to, what is the spread, which are the largest, and what is left after the largest
are removed — as SQL aggregates that stream over a Parquet file instead of loading it.

**The rule this module lives under.** The out-of-core path and the in-memory path must produce the
*same numbers*, not merely similar ones. An instrument that quietly answers differently depending
on which engine picked it up is worse than no instrument, because the disagreement is invisible in
the report. `selftest_ooc.py` is the gate that holds this to account, and it is why the SQL below
is written to mirror numpy's definitions exactly rather than whatever SQL finds convenient:

  * `stddev_samp` is numpy's `std(ddof=1)`.
  * every column is cast to DOUBLE on the way in, so no aggregate silently returns DECIMAL and
    compares unequal to a float that is in fact identical.
  * rows are filtered on `isfinite(x)`, matching the `r[np.isfinite(r)]` that every in-memory
    instrument applies first. NaN and +/-inf are dropped by both paths or by neither; a NaN left
    in on one side turns every downstream aggregate into NaN and the parity gate into noise.
  * "drop the top k" is done by ORDER BY ... OFFSET k, which drops k *rows by position*. Doing it
    by value (`WHERE x NOT IN (...)`) would remove every duplicate of a tied value and quietly
    change n. The instruments' whole subject is results that move when ties are broken differently
    (case study 1), so this module does not get to make that mistake.

**What "out-of-core" does and does not mean here.** The aggregates stream. The "drop the top k"
queries use ORDER BY, which duckdb buffers and, when it must, **spills to disk** rather than
failing -- that is the property that makes RED data workable at all, and it is why
`ISOLATION.md` §Sizing requires **disk >= 4x the client's raw data**. Memory therefore does not
stay flat as the file grows; it grows far more slowly than loading would. Measured on this box
over an 8x-58 MB range: the in-memory path costs about **6.7 MB of peak RSS per MB of file**, this
path about **2.0**. `selftest_ooc.py` gates that ratio, so a future change that quietly starts
loading the file fails the build instead of the engagement.

A faster top-k drop without the sort is possible (take the k-th largest, then aggregate the rows
below it and add back the tied remainder analytically). It is deliberately **not** used: it needs
a variance-merge step to stay numerically stable, and this file is handed to clients as evidence.
Legible and exactly equal to numpy beats clever and approximately equal. Revisit only if a real
engagement is disk-bound, which is a measurement, not a guess.

Readable on purpose: a client is handed these scripts as the evidence for a finding.
"""
from __future__ import annotations
import os

__all__ = ['available', 'engine_for', 'DUCKDB_MIN_BYTES', 'column_stats', 'top_values',
           'load_column', 'describe_engine']

# Below this, loading the column is simpler, faster and identical in result. The threshold is a
# convenience, not a correctness boundary -- either engine is correct at any size.
DUCKDB_MIN_BYTES = 64 * 1024 * 1024

PARQUET_SUFFIXES = ('.parquet', '.pq')


def available() -> bool:
    """Is the out-of-core engine installed? Pinned in requirements.txt, so normally yes."""
    try:
        import duckdb  # noqa: F401
        return True
    except ImportError:
        return False


def describe_engine() -> str:
    try:
        import duckdb
        return f'duckdb {duckdb.__version__}'
    except ImportError:
        return 'duckdb MISSING'


def engine_for(path: str, requested: str = 'auto') -> str:
    """Resolve 'auto' to a concrete engine, and fail loudly on an impossible request.

    'auto' picks duckdb only for a Parquet file that is large enough to be worth it. CSV is left
    to pandas: streaming it would mean re-parsing the text once per aggregate, which is slower
    than loading it, and a client who exports tick data as CSV has a different problem first.
    """
    if requested not in ('auto', 'pandas', 'duckdb'):
        raise ValueError(f'unknown engine {requested!r}')
    if requested == 'duckdb':
        if not available():
            raise RuntimeError('--engine duckdb requested but duckdb is not installed. '
                               'pip install -r requirements.txt, and do not edit the pins in place.')
        return 'duckdb'
    if requested == 'pandas':
        return 'pandas'
    big = os.path.getsize(path) >= DUCKDB_MIN_BYTES if os.path.exists(path) else False
    return 'duckdb' if (available() and path.endswith(PARQUET_SUFFIXES) and big) else 'pandas'


def _con(path: str):
    import duckdb
    con = duckdb.connect()
    # read_parquet rather than a materialised table: this is the whole point -- the file is
    # scanned per query, never loaded.
    con.execute(f"CREATE VIEW t AS SELECT * FROM read_parquet('{path}')")
    return con


def column_stats(path: str, column: str, drop_top: int = 0) -> dict:
    """n, sum, mean and sample sd of `column`, optionally after removing the `drop_top` largest.

    Streams the file. Returns exactly what numpy would return for the same rows.
    """
    con = _con(path)
    try:
        inner = (f'SELECT x FROM (SELECT CAST("{column}" AS DOUBLE) AS x FROM t) '
                 f'WHERE x IS NOT NULL AND isfinite(x)')
        if drop_top:
            inner += f' ORDER BY x DESC OFFSET {int(drop_top)}'
        row = con.execute(
            f'SELECT count(*), sum(x), avg(x), stddev_samp(x) FROM ({inner})').fetchone()
    finally:
        con.close()
    n, total, mean, sd = row
    return {
        'n': int(n or 0),
        'total': float(total) if total is not None else 0.0,
        'mean': float(mean) if mean is not None else float('nan'),
        'sd': float(sd) if sd is not None else float('nan'),
    }


def top_values(path: str, column: str, k: int) -> list[float]:
    """The k largest values, descending. Streams; only k rows are ever held."""
    con = _con(path)
    try:
        rows = con.execute(
            f'SELECT x FROM (SELECT CAST("{column}" AS DOUBLE) AS x FROM t) '
            f'WHERE x IS NOT NULL AND isfinite(x) ORDER BY x DESC LIMIT {int(k)}').fetchall()
    finally:
        con.close()
    return [float(r[0]) for r in rows]


def load_column(path: str, column: str | None = None):
    """The in-memory path: read the column into a numpy array. Unchanged behaviour from v4."""
    import numpy as np
    import pandas as pd
    df = pd.read_parquet(path) if path.endswith(PARQUET_SUFFIXES) else pd.read_csv(path)
    col = column or df.select_dtypes('number').columns[-1]
    if col not in df.columns:
        raise KeyError(f'column {col!r} not in {path} (have: {list(df.columns)})')
    a = df[col].to_numpy(dtype=float)
    return a[np.isfinite(a)], col
