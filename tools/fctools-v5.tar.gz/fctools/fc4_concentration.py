#!/usr/bin/env python3
"""FC-4 — how much of the result rests on one observation?

The instrument behind case study 2, where a single bad print carried thirty months of apparent
return. A backtest can be genuinely profitable, or it can be one lucky row and a lot of noise;
the summary statistic looks the same either way.

Removes the largest contributors one at a time and reports what is left. The question it answers
is blunt: **if the single best day were a data error, would there still be a strategy?**

    python3 fc4_concentration.py returns.csv --column pnl
    python3 fc4_concentration.py big.parquet --column pnl --engine duckdb
    python3 fc4_concentration.py --selftest

**Two engines, one answer.** `analyse()` works on an array in memory; `analyse_ooc()` asks the
same questions of a Parquet file as SQL aggregates, so tick and order-book panels that cannot be
loaded can still be checked. They are required to agree, and `selftest_ooc.py` is the gate that
enforces it -- see `fcdata.py` for why that rule is written down rather than assumed.
"""
from __future__ import annotations
import argparse, sys
import numpy as np
import fcdata
from fcutil import banner, verdict, sharpe, TRADING_DAYS

FRAGILE_SHARE = 0.25   # one row carrying a quarter of the total is a finding


def analyse(r: np.ndarray, periods_per_year: int = TRADING_DAYS) -> dict:
    r = np.asarray(r, dtype=float)
    r = r[np.isfinite(r)]
    total = float(r.sum())
    order = np.argsort(r)[::-1]           # biggest positive contributor first
    res = {
        'n': int(r.size),
        'total': total,
        'mean': float(r.mean()),
        'sharpe': sharpe(r, periods_per_year),
        'top1_value': float(r[order[0]]),
        'top1_share': float(r[order[0]] / total) if total != 0 else float('nan'),
        'drops': [],
    }
    for k in _drop_ks(r.size):
        kept = np.delete(r, order[:k])
        res['drops'].append({
            'k': int(k),
            'pct_of_rows': k / r.size * 100.0,
            'total': float(kept.sum()),
            'mean': float(kept.mean()),
            'sharpe': sharpe(kept, periods_per_year),
            'sign_flips': bool(np.sign(kept.sum()) != np.sign(total)),
            'share_lost': float(1 - kept.sum() / total) if total != 0 else float('nan'),
        })
    res['finding'] = bool(res['top1_share'] > FRAGILE_SHARE or res['drops'][0]['sign_flips'])
    return res


def _drop_ks(n: int) -> tuple[int, ...]:
    """The three cut depths, in one place so both engines cannot drift apart."""
    return (1, 5, max(1, n // 100))


def analyse_ooc(path: str, column: str, periods_per_year: int = TRADING_DAYS) -> dict:
    """`analyse()` without loading the column, for files that do not fit in RAM.

    Returns the identical dict, computed from streaming SQL aggregates. Every number here has a
    counterpart in `analyse()` and the two are checked against each other by `selftest_ooc.py`.
    """
    base = fcdata.column_stats(path, column)
    n, total = base['n'], base['total']
    if n == 0:
        raise ValueError(f'no finite values in column {column!r} of {path}')
    top1 = fcdata.top_values(path, column, 1)[0]
    res = {
        'n': n,
        'total': total,
        'mean': base['mean'],
        'sharpe': (base['mean'] / base['sd'] * np.sqrt(periods_per_year)
                   if base['sd'] and np.isfinite(base['sd']) and base['sd'] != 0 else float('nan')),
        'top1_value': top1,
        'top1_share': float(top1 / total) if total != 0 else float('nan'),
        'drops': [],
        'engine': 'duckdb',
    }
    for k in _drop_ks(n):
        kept = fcdata.column_stats(path, column, drop_top=k)
        res['drops'].append({
            'k': int(k),
            'pct_of_rows': k / n * 100.0,
            'total': kept['total'],
            'mean': kept['mean'],
            'sharpe': (kept['mean'] / kept['sd'] * np.sqrt(periods_per_year)
                       if kept['sd'] and np.isfinite(kept['sd']) and kept['sd'] != 0 else float('nan')),
            'sign_flips': bool(np.sign(kept['total']) != np.sign(total)),
            'share_lost': float(1 - kept['total'] / total) if total != 0 else float('nan'),
        })
    res['finding'] = bool(res['top1_share'] > FRAGILE_SHARE or res['drops'][0]['sign_flips'])
    return res


def report(res: dict) -> str:
    L = [banner('FC-4 — concentration: how much rests on the largest rows?')]
    L.append(f"  engine                  {res.get('engine', 'pandas')}")
    L.append(f"  observations            {res['n']:,}")
    L.append(f"  total                   {res['total']:+.4f}   mean {res['mean']:+.6f}   Sharpe {res['sharpe']:.3f}")
    L.append(f"  single largest row      {res['top1_value']:+.4f}   "
             f"= {res['top1_share']*100:.1f}% of the entire result")
    L.append('')
    L.append('  removing the largest contributors:')
    for d in res['drops']:
        flag = '   <- SIGN FLIPS' if d['sign_flips'] else ''
        L.append(f"    drop top {d['k']:<4d} ({d['pct_of_rows']:5.2f}% of rows)   "
                 f"total {d['total']:+.4f}   Sharpe {d['sharpe']:6.3f}   "
                 f"{d['share_lost']*100:5.1f}% of the result gone{flag}")
    L.append('')
    L.append(verdict(
        not res['finding'],
        'the result is spread across many observations, not carried by a few',
        f"{res['top1_share']*100:.1f}% of the result comes from ONE observation"
        + (' — and removing it flips the sign' if res['drops'][0]['sign_flips'] else '')
        + '. Verify that row against the raw source before trusting anything downstream.'))
    return '\n'.join(L)


def selftest() -> int:
    """A strategy with no edge, plus one bad print worth 40% in a day."""
    rng = np.random.default_rng(4)
    r = rng.normal(0.0, 0.01, 900)
    r[418] = 0.40                                  # the fat-fingered tick
    res = analyse(r)
    print(report(res))
    print(f"\n  selftest: the single bad row is caught -> {'OK' if res['finding'] else 'FAILED'}")
    print(f"  selftest: removing it flips the sign   -> "
          f"{'OK' if res['drops'][0]['sign_flips'] else '(not in this draw)'}")
    return 0 if res['finding'] else 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('path', nargs='?')
    ap.add_argument('--column', default=None)
    ap.add_argument('--periods-per-year', type=int, default=TRADING_DAYS)
    ap.add_argument('--engine', default='auto', choices=('auto', 'pandas', 'duckdb'),
                    help='auto picks duckdb for a large Parquet file; both give the same answer')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if not a.path:
        ap.error('give a path, or --selftest')

    engine = fcdata.engine_for(a.path, a.engine)
    if engine == 'duckdb':
        if not a.column:
            ap.error('--column is required with the duckdb engine: streaming the file means we '
                     'never see the frame, so the column cannot be guessed')
        print(f'  reading {a.path}, column "{a.column}", engine duckdb (streamed, not loaded)')
        print(report(analyse_ooc(a.path, a.column, a.periods_per_year)))
        return 0

    r, col = fcdata.load_column(a.path, a.column)
    print(f'  reading {a.path}, column "{col}", engine pandas (loaded)')
    res = analyse(r, a.periods_per_year)
    res['engine'] = 'pandas'
    print(report(res))
    return 0


if __name__ == '__main__':
    sys.exit(main())
