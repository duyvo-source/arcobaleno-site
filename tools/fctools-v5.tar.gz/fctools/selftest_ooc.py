#!/usr/bin/env python3
"""The RED-tier gate: prove the out-of-core engine gives the SAME answer as the in-memory one.

Adding duckdb is what lets an audit touch tick and order-book data at all. It also introduces the
one failure mode that would be invisible in a report: an instrument that answers differently
depending on which engine happened to pick up the file. A wrong number that announces itself is a
bug; a wrong number that only appears on large inputs is a wrong finding sent to a client.

So this is not a smoke test. It runs both engines over the *same file*, in separate processes, and
holds them to four properties:

  1. **The planted defect is found by both.** `fc4_concentration` exists to catch one bad row
     carrying the result. If the streaming path misses it, the path is useless.
  2. **Every number agrees**, to floating-point tolerance, field by field -- not just the verdict.
     Two engines that agree on "finding: yes" while disagreeing on the share are not agreeing.
  3. **Ties are dropped by position, not by value.** "Remove the top k" must remove exactly k rows
     even when the largest value appears many times. Removing every duplicate instead silently
     changes n, and results that move when ties are broken differently are the subject of case
     study 1 -- this toolkit does not get to make that mistake in its own plumbing.
  4. **Memory does not scale the way loading does.** Measured as peak RSS of each engine at two
     file sizes, reported as **MB of RSS per MB of file**. The streaming path is not flat -- the
     "drop top k" queries sort, and duckdb spills to disk (see `fcdata.py`) -- so the honest gate
     is the *rate*, not the absolute. A change that quietly started loading the file would push
     the rate up to the in-memory path's and fail here.

    python3 selftest_ooc.py                 # the gate
    python3 selftest_ooc.py --rows 2000000  # smaller/faster while developing

**What this gate does NOT establish:** that any particular instance can handle any particular
client's data. It proves correctness and that memory does not scale with the file. The actual
ceiling is a measurement on the instance type chosen for the engagement -- see `INTAKE.md` Part B,
which requires exactly that before an L2 job is quoted.
"""
from __future__ import annotations
import argparse, json, math, os, resource, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
RTOL = 1e-9
FIELDS = ('n', 'total', 'mean', 'sharpe', 'top1_value', 'top1_share', 'finding')
DROP_FIELDS = ('k', 'total', 'mean', 'sharpe', 'sign_flips', 'share_lost')


# ---------------------------------------------------------------------------------------------
# worker: run ONE engine in ITS OWN process, so peak RSS is that engine's and nobody else's
# ---------------------------------------------------------------------------------------------
def worker(path: str, column: str, engine: str) -> int:
    sys.path.insert(0, HERE)
    import fc4_concentration as fc4
    res = fc4.analyse_ooc(path, column) if engine == 'duckdb' else \
        fc4.analyse(fc4.fcdata.load_column(path, column)[0])
    res['peak_rss_mb'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0
    print(json.dumps(res, default=float))
    return 0


def run_engine(path: str, column: str, engine: str) -> dict:
    p = subprocess.run([sys.executable, os.path.abspath(__file__),
                        '--worker', path, '--column', column, '--engine', engine],
                       capture_output=True, text=True, cwd=HERE)
    if p.returncode != 0:
        raise RuntimeError(f'{engine} worker failed:\n{p.stdout[-800:]}\n{p.stderr[-800:]}')
    return json.loads(p.stdout.strip().splitlines()[-1])


# ---------------------------------------------------------------------------------------------
# fixtures
# ---------------------------------------------------------------------------------------------
def make_file(path: str, rows: int, kind: str) -> None:
    import numpy as np, pandas as pd
    rng = np.random.default_rng(20260916)
    r = rng.normal(0.0, 0.01, rows)
    if kind == 'planted':
        r[rows // 3] = 0.40 * rows / 900.0      # one print big enough to carry the whole result
    elif kind == 'tied':
        r[:64] = 0.25                           # 64 identical values, all at the maximum
    pd.DataFrame({'pnl': r}).to_parquet(path, index=False)


# ---------------------------------------------------------------------------------------------
# comparisons
# ---------------------------------------------------------------------------------------------
def close(a, b) -> bool:
    if isinstance(a, bool) or isinstance(b, bool):
        return bool(a) == bool(b)
    a, b = float(a), float(b)
    if math.isnan(a) and math.isnan(b):
        return True
    return math.isclose(a, b, rel_tol=RTOL, abs_tol=1e-12)


def compare(pd_res: dict, dd_res: dict) -> list[str]:
    bad = []
    for f in FIELDS:
        if not close(pd_res[f], dd_res[f]):
            bad.append(f'{f}: pandas {pd_res[f]!r} vs duckdb {dd_res[f]!r}')
    for i, (p, d) in enumerate(zip(pd_res['drops'], dd_res['drops'])):
        for f in DROP_FIELDS:
            if not close(p[f], d[f]):
                bad.append(f'drops[{i}].{f}: pandas {p[f]!r} vs duckdb {d[f]!r}')
    return bad


def check(label: str, ok: bool, detail: str = '') -> bool:
    print(f"  {'PASS' if ok else 'FAIL'}  {label}{('  — ' + detail) if detail else ''}")
    return ok


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--rows', type=int, default=6_000_000)
    ap.add_argument('--worker'); ap.add_argument('--column', default='pnl'); ap.add_argument('--engine')
    a = ap.parse_args()
    if a.worker:
        return worker(a.worker, a.column, a.engine)

    try:
        import duckdb  # noqa: F401
    except ImportError:
        print('  FAIL  duckdb is not installed — this bundle pins it in requirements.txt.')
        print('        Install the pinned stack; do not edit the pins in place on an engagement box.')
        return 1

    ok = True
    with tempfile.TemporaryDirectory() as tmp:
        # ---- 1 & 2: planted defect found by both, and full field-for-field parity ----
        planted = os.path.join(tmp, 'planted.parquet')
        make_file(planted, a.rows, 'planted')
        size_mb = os.path.getsize(planted) / 1e6
        print(f'\n  fixture: {a.rows:,} rows, {size_mb:,.1f} MB parquet, one planted bad print\n')

        pd_res, dd_res = run_engine(planted, 'pnl', 'pandas'), run_engine(planted, 'pnl', 'duckdb')

        ok &= check('the planted row is caught by the in-memory path', pd_res['finding'])
        ok &= check('the planted row is caught by the streaming path', dd_res['finding'])
        diffs = compare(pd_res, dd_res)
        ok &= check(f'both engines agree on every field ({len(FIELDS) + len(DROP_FIELDS) * 3} compared)',
                    not diffs, '; '.join(diffs[:3]))
        ok &= check('both engines agree the result is one row',
                    close(pd_res['top1_share'], dd_res['top1_share']),
                    f"share {dd_res['top1_share'] * 100:.1f}%")

        # ---- 4: how fast does memory grow with the file? ----
        big = os.path.join(tmp, 'big.parquet')
        make_file(big, a.rows * 4, 'planted')
        big_mb = os.path.getsize(big) / 1e6
        added = big_mb - size_mb
        rates = {}
        for eng, small_res in (('pandas', pd_res), ('duckdb', dd_res)):
            big_res = run_engine(big, 'pnl', eng)
            rates[eng] = (big_res['peak_rss_mb'] - small_res['peak_rss_mb']) / added
        ok &= check('memory grows more slowly than loading, by a clear margin',
                    rates['duckdb'] < 0.5 * rates['pandas'],
                    f"MB RSS per MB of file over {size_mb:,.0f} -> {big_mb:,.0f} MB: "
                    f"pandas {rates['pandas']:.1f}, duckdb {rates['duckdb']:.1f} "
                    f"({rates['pandas'] / rates['duckdb']:.1f}x slower growth)")

        # ---- 3: ties are dropped by position, not by value ----
        tied = os.path.join(tmp, 'tied.parquet')
        make_file(tied, min(a.rows, 500_000), 'tied')
        t_pd, t_dd = run_engine(tied, 'pnl', 'pandas'), run_engine(tied, 'pnl', 'duckdb')
        n = t_dd['n']
        # 64 identical maxima: dropping the top 5 must remove 5 rows, never all 64.
        want = n - 5
        got_pd = t_pd['n'] - round(t_pd['drops'][1]['pct_of_rows'] / 100.0 * t_pd['n'])
        ok &= check('64 tied maxima: "drop top 5" removes 5 rows, not every duplicate',
                    close(t_pd['drops'][1]['total'], t_dd['drops'][1]['total']) and got_pd == want,
                    f'n {n:,} -> {want:,}')
        ok &= check('tied fixture agrees field for field', not compare(t_pd, t_dd))

        # ---- negative control: a clean file must NOT raise a finding on either engine ----
        clean = os.path.join(tmp, 'clean.parquet')
        make_file(clean, min(a.rows, 500_000), 'clean')
        c_pd, c_dd = run_engine(clean, 'pnl', 'pandas'), run_engine(clean, 'pnl', 'duckdb')
        ok &= check('negative control: neither engine cries wolf on clean data',
                    not c_pd['finding'] and not c_dd['finding'])
        ok &= check('clean fixture agrees field for field', not compare(c_pd, c_dd))

    print(f"\n  {'OK — the streaming path is safe to use on an engagement' if ok else '**GATE FAILED** — do not ship this bundle'}")
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
