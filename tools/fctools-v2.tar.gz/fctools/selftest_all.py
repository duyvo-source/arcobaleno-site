#!/usr/bin/env python3
"""Run every instrument's self-test. This is the toolkit's own FC-1.

Each instrument ships with a synthetic case reproducing the defect it was built to find. If one of
these fails, the instrument is broken and any finding it produced is unsafe to hand a client.

    python3 selftest_all.py
"""
import os, subprocess, sys

# Resolve instruments relative to THIS FILE, not the caller's working directory: the toolkit is
# unpacked next to the client's data and run from wherever that happens to be, and a gate that
# only works from one cwd is a gate that gets skipped under time pressure.
HERE = os.path.dirname(os.path.abspath(__file__))

TOOLS = [
    ('fc1_reproduce.py',     'FC-1  does it repeat'),
    ('fc4_concentration.py', 'FC-4  one row carrying the result'),
    ('fc6_episodes.py',      'FC-6  trades versus episodes'),
    ('fc8_bootstrap.py',     'FC-8  i.i.d. versus block CI'),
    ('fc8_ordering.py',      'FC-8  sort order sensitivity'),
]

def main() -> int:
    failed = []
    for script, label in TOOLS:
        p = subprocess.run([sys.executable, os.path.join(HERE, script), '--selftest'],
                           capture_output=True, text=True, cwd=HERE)
        status = 'PASS' if p.returncode == 0 else 'FAIL'
        print(f'  {status}  {label:<38} ({script})')
        if p.returncode != 0:
            failed.append((script, p.stdout[-600:], p.stderr[-600:]))
    print(f'\n  {len(TOOLS) - len(failed)}/{len(TOOLS)} instruments pass')
    for script, out, err in failed:
        print(f'\n--- {script} ---\n{out}\n{err}')
    return 1 if failed else 0

if __name__ == '__main__':
    sys.exit(main())
