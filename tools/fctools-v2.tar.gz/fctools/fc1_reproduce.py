#!/usr/bin/env python3
"""FC-1 — does it repeat?

The first check of every engagement, and the one that ends a Triage early when it fails. Runs the
client's backtest several times and compares what comes out. Nothing downstream means anything
until this passes.

Two things are varied deliberately, because they catch different bugs:

  * **Repeat runs in an identical environment** catch anything seeded from the clock, from thread
    scheduling, or from iteration over an unordered container.
  * **Repeat runs under different `PYTHONHASHSEED` values** catch the specific and very common case
    where the code iterates a `set` or `dict` whose order Python randomises per process. That is
    the defect behind case study 1, and it is invisible in a single session because the seed is
    fixed for the life of one interpreter.

    python3 fc1_reproduce.py --cmd "python3 backtest.py" --runs 3
    python3 fc1_reproduce.py --cmd "python3 backtest.py" --artifact results.json
    python3 fc1_reproduce.py --selftest
"""
from __future__ import annotations
import argparse, hashlib, os, subprocess, sys, tempfile
from fcutil import banner, verdict


def _digest(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def run_once(cmd: str, hashseed: str | None, artifact: str | None, cwd: str | None) -> dict:
    env = dict(os.environ)
    if hashseed is not None:
        env['PYTHONHASHSEED'] = hashseed
    p = subprocess.run(cmd, shell=True, capture_output=True, cwd=cwd, env=env, timeout=3600)
    out = {'returncode': p.returncode, 'stdout_sha': _digest(p.stdout),
           'stdout_head': p.stdout.decode('utf-8', 'replace')[:400],
           'stderr_head': p.stderr.decode('utf-8', 'replace')[-400:]}
    if artifact:
        try:
            with open(os.path.join(cwd or '.', artifact), 'rb') as f:
                out['artifact_sha'] = _digest(f.read())
        except OSError as e:
            out['artifact_sha'] = f'MISSING ({e.__class__.__name__})'
    return out


def analyse(cmd: str, runs: int = 3, artifact: str | None = None, cwd: str | None = None,
            vary_hashseed: bool = True) -> dict:
    key = 'artifact_sha' if artifact else 'stdout_sha'
    same_env = [run_once(cmd, '0', artifact, cwd) for _ in range(runs)]
    res = {'cmd': cmd, 'runs': runs, 'compared_on': key, 'same_env': same_env,
           'failed': [r for r in same_env if r['returncode'] != 0]}
    res['same_env_hashes'] = sorted({r[key] for r in same_env})
    res['same_env_stable'] = len(res['same_env_hashes']) == 1
    if vary_hashseed:
        seeds = ['1', '12345', '99991']
        varied = [run_once(cmd, s, artifact, cwd) for s in seeds]
        res['hashseeds'] = seeds
        res['varied'] = varied
        res['varied_hashes'] = sorted({r[key] for r in varied} | {res['same_env_hashes'][0]})
        res['hashseed_stable'] = len(res['varied_hashes']) == 1
    else:
        res['hashseed_stable'] = True
    res['finding'] = not (res['same_env_stable'] and res['hashseed_stable'])
    return res


def report(res: dict) -> str:
    L = [banner('FC-1 — does it repeat?')]
    L.append(f"  command                 {res['cmd']}")
    L.append(f"  compared on             {res['compared_on']}")
    if res['failed']:
        L.append(f"\n  *** {len(res['failed'])} of {res['runs']} runs exited non-zero. "
                 f"Last stderr:\n{res['failed'][-1]['stderr_head']}")
    same_env_msg = ('same answer every time' if res['same_env_stable']
                    else f"{len(res['same_env_hashes'])} DIFFERENT answers")
    L.append(f"\n  {res['runs']} runs, identical environment    {same_env_msg}")
    for h in res['same_env_hashes']:
        L.append(f"      {h[:16]}…")
    if 'varied_hashes' in res:
        varied_msg = ('stable' if res['hashseed_stable']
                      else f"{len(res['varied_hashes'])} DIFFERENT answers")
        L.append(f"\n  across PYTHONHASHSEED {', '.join(res['hashseeds'])}  {varied_msg}")
        for h in res['varied_hashes']:
            L.append(f"      {h[:16]}…")
    L.append('')
    if not res['same_env_stable']:
        L.append(verdict(False, '', 'the same code on the same data does not produce the same '
                                    'answer twice. Stop here — nothing downstream can be checked '
                                    'until this is fixed.'))
    elif not res['hashseed_stable']:
        L.append(verdict(False, '', 'stable within one process but NOT across PYTHONHASHSEED. The '
                                    'code iterates a set or dict somewhere and inherits its order. '
                                    'Every run in a fresh process is a different portfolio.'))
    else:
        L.append(verdict(True, 'the result is reproducible across runs and across hash seeds', ''))
    return '\n'.join(L)


def selftest() -> int:
    """A script that ranks tied items by iterating a set — case study 1's defect, in four lines."""
    with tempfile.TemporaryDirectory() as td:
        script = os.path.join(td, 'ranker.py')
        with open(script, 'w') as f:
            f.write(
                "items = {'AAA','BBB','CCC','DDD','EEE','FFF','GGG','HHH'}\n"
                "# every item has the same score, so the tie-break is set iteration order\n"
                "picked = [x for x in items][:3]\n"
                "print('portfolio:', picked)\n")
        res = analyse(f'python3 {script}', runs=3, cwd=td)
        print(report(res))
        ok = res['same_env_stable'] and not res['hashseed_stable']
        print(f"\n  selftest: stable inside one hash seed        -> "
              f"{'OK' if res['same_env_stable'] else 'FAILED'}")
        print(f"  selftest: hash-seed dependence is caught     -> "
              f"{'OK' if not res['hashseed_stable'] else 'FAILED'}")
        return 0 if ok else 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--cmd', help='the command that produces the result')
    ap.add_argument('--runs', type=int, default=3)
    ap.add_argument('--artifact', default=None, help='compare this output file instead of stdout')
    ap.add_argument('--cwd', default=None)
    ap.add_argument('--no-hashseed', action='store_true', help='skip the PYTHONHASHSEED sweep')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if not a.cmd:
        ap.error('give --cmd, or --selftest')
    res = analyse(a.cmd, a.runs, a.artifact, a.cwd, not a.no_hashseed)
    print(report(res))
    return 1 if res['finding'] else 0


if __name__ == '__main__':
    sys.exit(main())
