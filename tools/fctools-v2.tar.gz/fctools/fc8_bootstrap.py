#!/usr/bin/env python3
"""FC-8 — is the margin of error wide enough to include zero?

The instrument that produced case study 7. A backtest's daily P&L is almost never independent:
a rule that holds the same position for days at a time produces runs of correlated days. The
ordinary bootstrap assumes independence, counts the same evidence repeatedly, and returns an
interval that is far too narrow. A moving-block bootstrap resamples contiguous blocks instead,
which keeps the clumping intact.

**The finding this looks for is the gap between the two**, not either interval alone: a result
whose i.i.d. interval excludes zero and whose block interval includes it was never significant —
it only looked that way because of how the uncertainty was computed.

    python3 fc8_bootstrap.py returns.csv --column pnl --block 10
    python3 fc8_bootstrap.py --selftest
"""
from __future__ import annotations
import argparse, sys
import numpy as np
from fcutil import sharpe, cagr, summarise, banner, verdict, TRADING_DAYS


def iid_bootstrap(r: np.ndarray, stat, n: int, rng) -> np.ndarray:
    idx = rng.integers(0, r.size, size=(n, r.size))
    return np.array([stat(r[i]) for i in idx])


def block_bootstrap(r: np.ndarray, stat, n: int, block: int, rng) -> np.ndarray:
    """Moving-block: draw ceil(N/block) starting points, concatenate, trim to N."""
    if block < 1:
        raise ValueError('block must be >= 1')
    if block >= r.size:
        raise ValueError(f'block ({block}) must be smaller than the series ({r.size})')
    n_blocks = int(np.ceil(r.size / block))
    starts = rng.integers(0, r.size - block + 1, size=(n, n_blocks))
    offsets = np.arange(block)
    out = np.empty(n)
    for k in range(n):
        idx = (starts[k][:, None] + offsets).ravel()[:r.size]
        out[k] = stat(r[idx])
    return out


def analyse(r: np.ndarray, block: int = 10, n: int = 2000, seed: int = 0,
            periods_per_year: int = TRADING_DAYS) -> dict:
    rng = np.random.default_rng(seed)
    r = np.asarray(r, dtype=float)
    r = r[np.isfinite(r)]
    stat = lambda x: cagr(x, periods_per_year)
    point = stat(r)
    res = {
        'n_periods': int(r.size),
        'point_cagr_pct': point,
        'point_sharpe': sharpe(r, periods_per_year),
        'lag1_autocorr': float(np.corrcoef(r[:-1], r[1:])[0, 1]) if r.size > 2 else float('nan'),
        'block': block,
        'iid': summarise(iid_bootstrap(r, stat, n, rng)),
        'block_boot': summarise(block_bootstrap(r, stat, n, block, rng)),
    }
    for key in ('iid', 'block_boot'):
        d = res[key]
        d['ci95'] = (d['p5'], d['p95'])
        d['includes_zero'] = bool(d['p5'] <= 0.0 <= d['p95'])
    res['finding'] = (not res['iid']['includes_zero']) and res['block_boot']['includes_zero']
    return res


def report(res: dict) -> str:
    L = [banner('FC-8 — confidence interval, i.i.d. versus moving block')]
    L.append(f"  periods                 {res['n_periods']}")
    L.append(f"  point estimate          {res['point_cagr_pct']:.2f}% a year, Sharpe {res['point_sharpe']:.3f}")
    L.append(f"  lag-1 autocorrelation   {res['lag1_autocorr']:+.4f}"
             f"{'   <- days are NOT independent' if abs(res['lag1_autocorr']) > 0.05 else ''}")
    L.append('')
    for label, key in (('i.i.d. bootstrap      ', 'iid'), (f"block bootstrap (b={res['block']:<3d})", 'block_boot')):
        d = res[key]
        L.append(f"  {label}  95% CI [{d['ci95'][0]:+8.2f}%, {d['ci95'][1]:+8.2f}%]   width {d['p95']-d['p5']:7.2f}pp"
                 f"   {'includes zero' if d['includes_zero'] else 'excludes zero'}")
    widening = res['block_boot']['p95'] - res['block_boot']['p5']
    narrow = res['iid']['p95'] - res['iid']['p5']
    L.append(f"\n  the block interval is {widening / narrow:.2f}x the width of the i.i.d. one")
    L.append('')
    L.append(verdict(
        not res['finding'],
        'both methods agree on whether zero is inside the interval',
        'the i.i.d. interval EXCLUDES zero and the block interval INCLUDES it. '
        'The apparent significance is an artefact of assuming independent days.'))
    return '\n'.join(L)


def selftest() -> int:
    """A series with no real edge, but strong day-to-day persistence.

    The point estimate looks like an edge either way. Only the block bootstrap should notice
    that it cannot be distinguished from nothing.
    """
    rng = np.random.default_rng(11)
    n, phi = 1500, 0.35
    eps = rng.normal(0, 0.012, n)
    r = np.empty(n)
    r[0] = eps[0]
    for t in range(1, n):
        r[t] = phi * r[t - 1] + eps[t]      # AR(1): runs of same-signed days
    r += 0.00075                            # a drift that is real but small against the noise
    res = analyse(r, block=10, n=1500, seed=1)
    print('  synthetic series: AR(1) phi=0.35 with a small positive drift.')
    print('  It should look like a ~33%/year edge and survive neither test honestly.')
    print(report(res))
    wider = res['iid']['p95'] - res['iid']['p5'] < res['block_boot']['p95'] - res['block_boot']['p5']
    ok = wider and res['finding']
    print(f"\n  selftest: block interval wider than i.i.d.      -> {'OK' if wider else 'FAILED'}")
    print(f"  selftest: the i.i.d.-only significance is caught -> {'OK' if res['finding'] else 'FAILED'}")
    return 0 if ok else 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('path', nargs='?', help='CSV/Parquet of per-period returns (simple, not log)')
    ap.add_argument('--column', default=None, help='column holding the return series')
    ap.add_argument('--block', type=int, default=10, help='block length in periods (default 10)')
    ap.add_argument('--n', type=int, default=2000, help='bootstrap draws (default 2000)')
    ap.add_argument('--periods-per-year', type=int, default=TRADING_DAYS)
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if not a.path:
        ap.error('give a path, or --selftest')
    import pandas as pd
    df = pd.read_parquet(a.path) if a.path.endswith(('.parquet', '.pq')) else pd.read_csv(a.path)
    col = a.column or df.select_dtypes('number').columns[-1]
    print(f'  reading {a.path}, column "{col}"')
    print(report(analyse(df[col].to_numpy(), a.block, a.n, 0, a.periods_per_year)))
    return 0


if __name__ == '__main__':
    sys.exit(main())
