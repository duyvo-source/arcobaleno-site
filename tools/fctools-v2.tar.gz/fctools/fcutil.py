"""Shared helpers for the FC instruments.

Deliberately small. Every instrument must be readable by a client who has been handed it as the
evidence for a finding — that is the whole point of the service, so nothing clever lives here.
"""
from __future__ import annotations
import numpy as np

TRADING_DAYS = 365  # crypto trades every day; override per asset class


def sharpe(returns: np.ndarray, periods_per_year: int = TRADING_DAYS) -> float:
    """Annualised Sharpe of a per-period simple return series. Zero risk-free rate."""
    r = np.asarray(returns, dtype=float)
    r = r[np.isfinite(r)]
    if r.size < 2:
        return float('nan')
    sd = r.std(ddof=1)
    if sd == 0:
        return float('nan')
    return float(r.mean() / sd * np.sqrt(periods_per_year))


def cagr(returns: np.ndarray, periods_per_year: int = TRADING_DAYS) -> float:
    """Compound annual growth rate, in percent, from a per-period simple return series."""
    r = np.asarray(returns, dtype=float)
    r = r[np.isfinite(r)]
    if r.size == 0:
        return float('nan')
    growth = float(np.prod(1.0 + r))
    if growth <= 0:
        return float('-inf')
    years = r.size / periods_per_year
    return (growth ** (1.0 / years) - 1.0) * 100.0


def max_drawdown(returns: np.ndarray) -> float:
    """Worst peak-to-trough decline of the compounded curve, in percent (negative)."""
    r = np.asarray(returns, dtype=float)
    r = r[np.isfinite(r)]
    if r.size == 0:
        return float('nan')
    curve = np.cumprod(1.0 + r)
    peak = np.maximum.accumulate(curve)
    return float((curve / peak - 1.0).min() * 100.0)


def percentile_of(value: float, sample: np.ndarray) -> float:
    """Where `value` falls in `sample`, 0-100. The question FC-8 keeps asking of a headline."""
    s = np.asarray(sample, dtype=float)
    s = s[np.isfinite(s)]
    if s.size == 0:
        return float('nan')
    return float((s <= value).sum() / s.size * 100.0)


def summarise(sample: np.ndarray) -> dict:
    """Mean, sd and the spread of a bootstrap or permutation sample."""
    s = np.asarray(sample, dtype=float)
    s = s[np.isfinite(s)]
    return {
        'n': int(s.size),
        'mean': float(s.mean()),
        'sd': float(s.std(ddof=1)) if s.size > 1 else float('nan'),
        'p5': float(np.percentile(s, 5)),
        'p50': float(np.percentile(s, 50)),
        'p95': float(np.percentile(s, 95)),
        'lo': float(s.min()),
        'hi': float(s.max()),
    }


def banner(title: str, width: int = 72) -> str:
    return f"\n{'=' * width}\n{title}\n{'=' * width}"


def verdict(passed: bool, ok_msg: str, fail_msg: str) -> str:
    return f"  {'PASS' if passed else '**FINDING**'}  {ok_msg if passed else fail_msg}"
