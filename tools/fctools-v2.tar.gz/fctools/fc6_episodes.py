#!/usr/bin/env python3
"""FC-6 — how much independent evidence is actually here?

The instrument that produced case study 8. An event strategy's trade count is not its evidence
count: if the rule fires when the whole market moves, every trade inside one episode is the same
event happening to different assets. Two thousand trades can be six independent observations.

Clusters events two ways — by calendar week, and by a gap rule (events closer together than
`--gap` hours belong to the same episode) — then re-states the result per episode rather than per
trade, because the episode is the unit that is actually independent.

    python3 fc6_episodes.py events.csv --time ts --return pnl_pct --gap 24
    python3 fc6_episodes.py --selftest
"""
from __future__ import annotations
import argparse, sys
import numpy as np
import pandas as pd
from fcutil import banner, verdict, summarise

THIN = 30  # episodes below this and the trade count is actively misleading


def episodes_by_gap(ts: pd.Series, gap_hours: float) -> np.ndarray:
    """Label each event with an episode id; a gap longer than `gap_hours` starts a new one."""
    order = np.argsort(ts.to_numpy())
    sorted_ts = ts.to_numpy()[order]
    gaps = np.diff(sorted_ts) / np.timedelta64(1, 'h')
    ids_sorted = np.concatenate([[0], np.cumsum(gaps > gap_hours)])
    ids = np.empty(len(ts), dtype=int)
    ids[order] = ids_sorted
    return ids


def analyse(ts: pd.Series, rets: np.ndarray | None = None, gap_hours: float = 24.0) -> dict:
    ts = pd.to_datetime(ts)
    span_years = (ts.max() - ts.min()).total_seconds() / (365.25 * 24 * 3600)
    weeks = ts.dt.strftime('%G-W%V')
    gap_ids = episodes_by_gap(ts, gap_hours)

    res = {
        'n_events': int(len(ts)),
        'span_years': float(span_years),
        'distinct_weeks': int(weeks.nunique()),
        'distinct_episodes': int(len(np.unique(gap_ids))),
        'gap_hours': gap_hours,
        'largest_episode': int(pd.Series(gap_ids).value_counts().max()),
    }
    res['events_per_episode'] = res['n_events'] / res['distinct_episodes']
    res['episodes_per_year'] = res['distinct_episodes'] / span_years if span_years > 0 else float('nan')

    if rets is not None:
        rets = np.asarray(rets, dtype=float)
        per_episode = pd.Series(rets).groupby(gap_ids).mean().to_numpy()
        res['per_trade'] = {'n': int(rets.size), 'mean': float(np.nanmean(rets)),
                            'sem': float(np.nanstd(rets, ddof=1) / np.sqrt(rets.size))}
        res['per_episode'] = {'n': int(per_episode.size), 'mean': float(np.nanmean(per_episode)),
                              'sem': float(np.nanstd(per_episode, ddof=1) / np.sqrt(per_episode.size))}
        # the honest interval is the one built from episodes
        m, se = res['per_episode']['mean'], res['per_episode']['sem']
        res['per_episode']['ci95'] = (m - 1.96 * se, m + 1.96 * se)
        res['per_episode']['includes_zero'] = bool(m - 1.96 * se <= 0 <= m + 1.96 * se)
        mt, set_ = res['per_trade']['mean'], res['per_trade']['sem']
        res['per_trade']['ci95'] = (mt - 1.96 * set_, mt + 1.96 * set_)
        res['per_trade']['includes_zero'] = bool(mt - 1.96 * set_ <= 0 <= mt + 1.96 * set_)
        res['finding'] = (not res['per_trade']['includes_zero']) and res['per_episode']['includes_zero']
    else:
        res['finding'] = res['distinct_episodes'] < THIN
    return res


def report(res: dict) -> str:
    L = [banner('FC-6 — trade count versus evidence count')]
    L.append(f"  events (trades)         {res['n_events']:,}")
    L.append(f"  span                    {res['span_years']:.1f} years")
    L.append(f"  distinct calendar weeks {res['distinct_weeks']}")
    L.append(f"  distinct episodes       {res['distinct_episodes']}   (events more than {res['gap_hours']:g}h apart)")
    L.append(f"  events per episode      {res['events_per_episode']:.1f}   (largest episode: {res['largest_episode']:,} events)")
    L.append(f"  episodes per year       {res['episodes_per_year']:.1f}")
    if 'per_trade' in res:
        L.append('')
        for label, key in (('per trade  ', 'per_trade'), ('per episode', 'per_episode')):
            d = res[key]
            L.append(f"  {label}  n={d['n']:>6,}  mean {d['mean']:+.3f}  95% CI "
                     f"[{d['ci95'][0]:+.3f}, {d['ci95'][1]:+.3f}]  "
                     f"{'includes zero' if d['includes_zero'] else 'excludes zero'}")
        L.append(f"\n  the per-episode interval is "
                 f"{(res['per_episode']['sem'] / res['per_trade']['sem']):.1f}x wider — "
                 f"that ratio is how much the trade count was overstating the evidence")
        L.append('')
        L.append(verdict(
            not res['finding'],
            'the result holds when measured on independent episodes',
            'significant per trade, NOT significant per episode. The trade count is counting '
            'the same episodes repeatedly.'))
    else:
        L.append('')
        L.append(verdict(res['distinct_episodes'] >= THIN,
                         f"{res['distinct_episodes']} episodes is a workable evidence base",
                         f"only {res['distinct_episodes']} independent episodes behind "
                         f"{res['n_events']:,} trades — size the confidence to the episode count"))
    return '\n'.join(L)


def selftest() -> int:
    """200 assets reacting to 8 market-wide events. 1,600 trades, 8 observations."""
    rng = np.random.default_rng(3)
    n_ep, n_assets = 8, 200
    base = pd.Timestamp('2020-01-01')
    ts, rets = [], []
    for e in range(n_ep):
        t0 = base + pd.Timedelta(days=int(rng.integers(0, 2000)))
        shock = rng.normal(0.04, 0.05)              # the episode's own outcome
        for _ in range(n_assets):
            ts.append(t0 + pd.Timedelta(minutes=int(rng.integers(0, 180))))
            rets.append(shock + rng.normal(0, 0.01))  # assets mostly echo the episode
    res = analyse(pd.Series(ts), np.array(rets), gap_hours=24)
    print(report(res))
    print(f"\n  selftest: 1,600 trades reduced to {res['distinct_episodes']} episodes -> "
          f"{'OK' if res['distinct_episodes'] == n_ep else 'FAILED'}")
    print(f"  selftest: per-trade significance flagged as illusory -> "
          f"{'OK' if res['finding'] else 'FAILED'}")
    return 0 if (res['distinct_episodes'] == n_ep and res['finding']) else 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('path', nargs='?')
    ap.add_argument('--time', default='ts', help='timestamp column')
    ap.add_argument('--return', dest='ret', default=None, help='per-event return column (optional)')
    ap.add_argument('--gap', type=float, default=24.0, help='hours of quiet that separate episodes')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if not a.path:
        ap.error('give a path, or --selftest')
    df = pd.read_parquet(a.path) if a.path.endswith(('.parquet', '.pq')) else pd.read_csv(a.path)
    rets = df[a.ret].to_numpy() if a.ret else None
    print(report(analyse(df[a.time], rets, a.gap)))
    return 0


if __name__ == '__main__':
    sys.exit(main())
