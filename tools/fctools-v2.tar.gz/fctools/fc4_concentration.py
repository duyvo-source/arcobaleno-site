#!/usr/bin/env python3
"""FC-4 — how much of the result rests on one observation?

The instrument behind case study 2, where a single bad print carried thirty months of apparent
return. A backtest can be genuinely profitable, or it can be one lucky row and a lot of noise;
the summary statistic looks the same either way.

Removes the largest contributors one at a time and reports what is left. The question it answers
is blunt: **if the single best day were a data error, would there still be a strategy?**

    python3 fc4_concentration.py returns.csv --column pnl
    python3 fc4_concentration.py --selftest
"""
from __future__ import annotations
import argparse, sys
import numpy as np
from fcutil import banner, verdict, sharpe, TRADING_DAYS

FRAGILE_SHARE = 0.25   # one row carrying a quarter of the total is a finding


def analyse(r: np.ndarray, periods_per_year: int = TRADING_DAYS) -> dict:
    r = np.asarray(r, dtype=float)
    r = r[np.isfinite(r)]
    total = float(r.sum())
    order = np.argsort(r)[::-1]           # biggest positive contributor first
    res = {
        'n': int(r.size),
        'total': total,
        'mean': float(r.mean()),
        'sharpe': sharpe(r, periods_per_year),
        'top1_value': float(r[order[0]]),
        'top1_share': float(r[order[0]] / total) if total != 0 else float('nan'),
        'drops': [],
    }
    for k in (1, 5, max(1, r.size // 100)):
        kept = np.delete(r, order[:k])
        res['drops'].append({
            'k': int(k),
            'pct_of_rows': k / r.size * 100.0,
            'total': float(kept.sum()),
            'mean': float(kept.mean()),
            'sharpe': sharpe(kept, periods_per_year),
            'sign_flips': bool(np.sign(kept.sum()) != np.sign(total)),
            'share_lost': float(1 - kept.sum() / total) if total != 0 else float('nan'),
        })
    res['finding'] = bool(res['top1_share'] > FRAGILE_SHARE or res['drops'][0]['sign_flips'])
    return res


def report(res: dict) -> str:
    L = [banner('FC-4 — concentration: how much rests on the largest rows?')]
    L.append(f"  observations            {res['n']:,}")
    L.append(f"  total                   {res['total']:+.4f}   mean {res['mean']:+.6f}   Sharpe {res['sharpe']:.3f}")
    L.append(f"  single largest row      {res['top1_value']:+.4f}   "
             f"= {res['top1_share']*100:.1f}% of the entire result")
    L.append('')
    L.append('  removing the largest contributors:')
    for d in res['drops']:
        flag = '   <- SIGN FLIPS' if d['sign_flips'] else ''
        L.append(f"    drop top {d['k']:<4d} ({d['pct_of_rows']:5.2f}% of rows)   "
                 f"total {d['total']:+.4f}   Sharpe {d['sharpe']:6.3f}   "
                 f"{d['share_lost']*100:5.1f}% of the result gone{flag}")
    L.append('')
    L.append(verdict(
        not res['finding'],
        'the result is spread across many observations, not carried by a few',
        f"{res['top1_share']*100:.1f}% of the result comes from ONE observation"
        + (' — and removing it flips the sign' if res['drops'][0]['sign_flips'] else '')
        + '. Verify that row against the raw source before trusting anything downstream.'))
    return '\n'.join(L)


def selftest() -> int:
    """A strategy with no edge, plus one bad print worth 40% in a day."""
    rng = np.random.default_rng(4)
    r = rng.normal(0.0, 0.01, 900)
    r[418] = 0.40                                  # the fat-fingered tick
    res = analyse(r)
    print(report(res))
    print(f"\n  selftest: the single bad row is caught -> {'OK' if res['finding'] else 'FAILED'}")
    print(f"  selftest: removing it flips the sign   -> "
          f"{'OK' if res['drops'][0]['sign_flips'] else '(not in this draw)'}")
    return 0 if res['finding'] else 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('path', nargs='?')
    ap.add_argument('--column', default=None)
    ap.add_argument('--periods-per-year', type=int, default=TRADING_DAYS)
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if not a.path:
        ap.error('give a path, or --selftest')
    import pandas as pd
    df = pd.read_parquet(a.path) if a.path.endswith(('.parquet', '.pq')) else pd.read_csv(a.path)
    col = a.column or df.select_dtypes('number').columns[-1]
    print(f'  reading {a.path}, column "{col}"')
    print(report(analyse(df[col].to_numpy(), a.periods_per_year)))
    return 0


if __name__ == '__main__':
    sys.exit(main())
