#!/usr/bin/env python3
"""FC-8 / FC-1 — is the headline a number, or one draw from a range?

The instrument that produced case study 6. Wherever a backtest has a capacity constraint — a
position cap, a capital limit, a max-concurrent-trades rule — and more candidates arrive at once
than there is room for, *something* decides which get in. Very often that something is the
arbitrary order a sort happened to leave the rows in, which is not a property of the data and not
a decision anyone made.

This measures how much of the headline rests on that. It permutes rows **only within tied
timestamps**, never disturbing the real chronological sequence, re-runs the simulation each time,
and reports where the published figure falls in the resulting distribution.

A published figure at the 96th percentile of its own ordering distribution is not reproducible,
however many times the same code returns it.

    python3 fc8_ordering.py events.csv --time ts --sim mymodule:run --published 22.84
    python3 fc8_ordering.py --selftest

`--sim module:function` must accept an ordered DataFrame and return a float.
"""
from __future__ import annotations
import argparse, importlib, sys
import numpy as np
import pandas as pd
from fcutil import banner, verdict, summarise, percentile_of


def tie_profile(ts: pd.Series) -> dict:
    counts = ts.value_counts()
    tied = counts[counts > 1]
    return {
        'n_events': int(len(ts)),
        'distinct_timestamps': int(counts.size),
        'events_in_ties': int(tied.sum()),
        'pct_in_ties': float(tied.sum() / len(ts) * 100.0) if len(ts) else 0.0,
        'largest_tie': int(counts.max()) if counts.size else 0,
    }


def permute_within_ties(df: pd.DataFrame, time_col: str, rng) -> pd.DataFrame:
    """Shuffle rows inside each tied timestamp; the order of the timestamps themselves is fixed."""
    key = df[time_col].to_numpy()
    order = np.lexsort((rng.random(len(df)), key))   # random tiebreak, stable on the real key
    return df.iloc[order]


def canonical(df: pd.DataFrame, time_col: str, second_key: str | None) -> pd.DataFrame:
    keys = [time_col] + ([second_key] if second_key else [])
    return df.sort_values(keys, kind='stable')


def analyse(df: pd.DataFrame, sim, time_col: str = 'ts', n: int = 300,
            published: float | None = None, second_key: str | None = None,
            seed: int = 0) -> dict:
    rng = np.random.default_rng(seed)
    res = {'ties': tie_profile(df[time_col]), 'n_draws': n}
    draws = np.array([sim(permute_within_ties(df, time_col, rng)) for _ in range(n)], dtype=float)
    res['distribution'] = summarise(draws)
    if second_key and second_key in df.columns:
        res['canonical'] = float(sim(canonical(df, time_col, second_key)))
        res['canonical_percentile'] = percentile_of(res['canonical'], draws)
    if published is not None:
        res['published'] = float(published)
        res['published_percentile'] = percentile_of(published, draws)
        res['finding'] = not (5.0 <= res['published_percentile'] <= 95.0)
    else:
        res['finding'] = False
    res['_draws'] = draws
    return res


def report(res: dict) -> str:
    t, d = res['ties'], res['distribution']
    L = [banner('FC-8 — how much of the headline is the sort order?')]
    L.append(f"  events                    {t['n_events']:,} across {t['distinct_timestamps']:,} distinct timestamps")
    L.append(f"  events sharing a timestamp {t['events_in_ties']:,}  ({t['pct_in_ties']:.1f}%)")
    L.append(f"  largest single tie         {t['largest_tie']:,}")
    if t['pct_in_ties'] < 1.0:
        L.append('\n  Almost nothing is tied — ordering is very unlikely to matter here.')
    L.append('')
    L.append(f"  {res['n_draws']} orderings, shuffling only within ties:")
    L.append(f"    mean    {d['mean']:.3f}   sd {d['sd']:.3f}")
    L.append(f"    5-95%   {d['p5']:.3f} to {d['p95']:.3f}")
    L.append(f"    range   {d['lo']:.3f} to {d['hi']:.3f}   (spread {d['hi']-d['lo']:.3f})")
    if 'canonical' in res:
        L.append(f"\n  explicit stable sort      {res['canonical']:.3f}   "
                 f"({res['canonical_percentile']:.1f}th percentile)")
    if 'published' in res:
        L.append(f"  the published figure      {res['published']:.3f}   "
                 f"**{res['published_percentile']:.1f}th percentile**")
        L.append('')
        L.append(verdict(
            not res['finding'],
            'the published figure sits inside the central 90% of its own ordering distribution',
            f"the published figure sits at the {res['published_percentile']:.1f}th percentile of what "
            f"the same code produces under equally valid orderings. It will not reproduce."))
    return '\n'.join(L)


def _demo_sim(df: pd.DataFrame) -> float:
    """A capacity-constrained book: each period, take at most CAP trades, first come first served."""
    CAP = 5
    taken = df.groupby('period', sort=False).head(CAP)
    return float(taken['pnl'].mean() * 100)


def selftest() -> int:
    """Events arrive in big simultaneous clusters; the book only has room for five of them."""
    rng = np.random.default_rng(5)
    rows = []
    for p in range(120):
        n_at_once = int(rng.integers(1, 40))
        for _ in range(n_at_once):
            rows.append({'period': p, 'ts': pd.Timestamp('2024-01-01') + pd.Timedelta(days=p),
                         'pnl': rng.normal(0.01, 0.06)})
    df = pd.DataFrame(rows)
    df['coin'] = [f'C{i%37:02d}' for i in range(len(df))]
    res = analyse(df, _demo_sim, 'ts', n=300, second_key='coin', seed=2)
    # the "published" figure: what one arbitrary arrival order happened to give
    published = float(np.percentile(res['_draws'], 97))
    res2 = analyse(df, _demo_sim, 'ts', n=300, published=published, second_key='coin', seed=2)
    print(report(res2))
    ok = res2['finding'] and res2['ties']['pct_in_ties'] > 50
    print(f"\n  selftest: heavy ties detected                      -> "
          f"{'OK' if res2['ties']['pct_in_ties'] > 50 else 'FAILED'}")
    print(f"  selftest: an extreme published draw is flagged     -> {'OK' if res2['finding'] else 'FAILED'}")
    return 0 if ok else 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('path', nargs='?')
    ap.add_argument('--time', default='ts')
    ap.add_argument('--sim', default=None, help='module:function taking an ordered DataFrame -> float')
    ap.add_argument('--published', type=float, default=None)
    ap.add_argument('--second-key', default=None, help='column for the canonical stable sort, e.g. coin')
    ap.add_argument('--n', type=int, default=300)
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if not (a.path and a.sim):
        ap.error('give a path and --sim module:function, or --selftest')
    mod, fn = a.sim.split(':')
    sim = getattr(importlib.import_module(mod), fn)
    df = pd.read_parquet(a.path) if a.path.endswith(('.parquet', '.pq')) else pd.read_csv(a.path)
    df[a.time] = pd.to_datetime(df[a.time])
    print(report(analyse(df, sim, a.time, a.n, a.published, a.second_key)))
    return 0


if __name__ == '__main__':
    sys.exit(main())
