# FC TOOLKIT — the standing instruments

**Created 2026-09-11.** The FC-8 checks in `../PLAYBOOK.md` existed only as prose. Every one of the
eight published case studies was found by ad-hoc work, on our own code, with unlimited time. A paid
engagement has a deadline and somebody else's codebase, and the risk is not that the method is wrong
— it is that it gets improvised under time pressure and something gets skipped.

These are the checks that are **generic enough to be instruments** rather than fresh scripts each
time. They are not the whole method; they are the parts that repeat.

```
python3 selftest_all.py          # run every instrument against its own known-answer case
```

## What is here

| instrument | check | the case study it came from |
|---|---|---|
| `fc1_reproduce.py` | Run it several times, and across `PYTHONHASHSEED`. Same answer? | **1** — the result changed every time it ran |
| `fc4_concentration.py` | How much of the result rests on the single largest row? | **2** — one bad price produced a 192% annual return |
| `fc6_episodes.py` | Trade count versus independent episode count | **8** — two thousand trades, six weeks of evidence |
| `fc8_bootstrap.py` | i.i.d. versus moving-block confidence interval | **7** — nine versions, none told apart from zero |
| `fc8_ordering.py` | Does the headline depend on the sort order under a capacity cap? | **6** — a headline that was really a range |

Each runs standalone with `--selftest` and prints a finding, not a number to interpret.

## The rule these are built to

**Every instrument must be readable by the client who is handed it as the evidence.** That is the
promise in `../SERVICE.md` — *we don't claim anything we can't show you* — so nothing here is
clever, nothing is vectorised past legibility, and every one prints the reasoning alongside the
result. A finding a client cannot follow is an opinion with a number attached.

**Each ships with a synthetic case that reproduces the defect it hunts.** `selftest_all.py` is the
toolkit's own FC-1: if an instrument cannot find a planted bug, any finding it produced on client
code is unsafe to send.

## What is deliberately NOT here

- **FC-2 (survivorship)** and **FC-5 (staleness)** need the client's own universe and delisting
  data to mean anything; they are per-engagement scripts, not instruments. The method is in
  `../PLAYBOOK.md`.
- **FC-3 (costs)** is a one-line recomputation once you know the fee model — the hard part is
  finding out what the fee model actually was, which is a conversation, not a script.
- **FC-7 (tradability)** now has a published case study (case 9) but no general instrument: what
  counts as an open position is specific to the strategy's own bookkeeping, so the check is
  "re-run their engine with the open positions valued, and again with them discarded" rather than
  anything reusable. The worked example is
  `research/runs/grid-trading-v1/fc7-realized-2026-09-11/realized_only.py`, including the pattern
  worth copying: **verify the modified copy against the original engine on every window before
  trusting the counterfactual.**

## Notes on use

- `--periods-per-year` defaults to **365** (crypto trades every day). **Set it to 252 for
  equities** or the numbers will be wrong by 20%.
- Returns are **simple, not log**, everywhere.
- `fc8_ordering.py` needs the client's simulation as `module:function` taking an ordered DataFrame
  and returning one float. Wrapping their backtest to that shape is usually 20 minutes and is the
  only real setup cost in the set.
- **No network calls, by any instrument, ever** — verifiable: `grep -nE 'urllib|requests|socket|http' *.py`
  returns nothing. Your code and data never leave the machine because of anything in here.
- **Nothing writes to your data, and no instrument creates an output file.** All re-runnable.
- **Two precise exceptions, stated because a blanket "writes nothing" claim would be false and you
  would find it:** (1) `--selftest` writes a small synthetic script into a `TemporaryDirectory` that
  is deleted on exit — that is how the planted-bug cases are built; (2) `fc1_reproduce.py --cmd`
  runs **your** command, which does whatever your code does. The instrument writes nothing; the
  thing it invokes is yours.

## Validated against real data, not only synthetic cases

Run on `research/runs/cascade-selection-v1/events_enriched.pkl`, 2026-09-11:

**`fc8_ordering.py`'s tie profile reproduces the published figures exactly, from the raw table:**

| | published in the case study | measured by the instrument |
|---|---|---|
| events sharing a timestamp | 1,481 | **1,481** |
| share of all events | 72.2% | **72.28%** |
| largest single cluster | 194 | **194** |

**A one-row discrepancy, now RESOLVED — and it is a worked example of the thing this toolkit is
for.** The instrument reads **2,049 events across 664 distinct hours**; case study 8 says **2,050
across 665**. Both are correct, and they count **different stages of the same pipeline**:

| stage | events | hours | what it is |
|---|---|---|---|
| after the forward-window filter | **2,050** | **665** | the strategy's event universe — what the case study quotes |
| persisted to `events_enriched.pkl` | **2,049** | **664** | after regime enrichment — what the instrument reads |

**One row separates them: BTC, 2019-09-24 18:00 UTC, the earliest event in the dataset.** The
regime marker is BTC's trailing 30-day return, computed as `btc / btc.shift(30) - 1`, so it is
undefined for the first 30 days of the price series — the enrichment step drops that row. It was
the only event in its hour, which is why exactly one hour disappears too.

**Nothing is wrong with the data or the instrument.** What was wrong was comparing a number taken
from a persisted artifact against a number taken from an earlier stage **without saying they were
different stages** — a reconciliation failure, not an arithmetic one, and the most common shape of
finding in this whole practice. It cost one row and no percentage; on somebody else's backtest the
same shape is how a filter silently removes the observations that carried the result.

*One documented limit falls out of it: the regime split (bull/bear on trailing BTC) silently
excludes the dataset's earliest event. Immaterial at 1 in 2,050 and structurally unavoidable — you
cannot know a trailing 30-day return before the series starts — but it is a warm-up truncation, and
warm-up truncations belong in writing rather than in a reader's inference.*

**`fc6_episodes.py` independently re-derives the study's central conclusion.** Clustering on a
24-hour gap gives 342 episodes behind 2,049 trades. **Weighted per trade, the mean return excludes
zero. Weighted per episode — one vote per independent event — it includes zero.** The per-episode
mean is roughly **one thirtieth** of the per-trade mean.

*Levels are deliberately given as a ratio. This sample belongs to a strategy family that is still
running, and the standing rule on this site is that published material must not make a live strategy
recoverable: publish ratios, strip parameters and levels.*

Read that carefully, because it is easy to over-claim: it does **not** say the strategy has no edge.
It says that when every episode is weighted equally, the edge disappears — which is the same thing
the original study found by a different route, that the return lives in the rare market-wide
cascades and isolated single-asset shocks have none. **An instrument agreeing with a finding it was
not told about is the strongest evidence available that both are right.**
