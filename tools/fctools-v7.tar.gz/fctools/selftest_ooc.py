#!/usr/bin/env python3
"""The RED-tier gate: prove the out-of-core engine gives the SAME answer as the in-memory one.

Adding duckdb is what lets an audit touch tick and order-book data at all. It also introduces the
one failure mode that would be invisible in a report: an instrument that answers differently
depending on which engine happened to pick up the file. A wrong number that announces itself is a
bug; a wrong number that only appears on large inputs is a wrong finding sent to a client.

So this is not a smoke test. It runs both engines over the *same file*, in separate processes, and
holds them to four properties:

  1. **The planted defect is found by both.** `fc4_concentration` exists to catch one bad row
     carrying the result. If the streaming path misses it, the path is useless.
  2. **Every number agrees**, to floating-point tolerance, field by field -- not just the verdict.
     Two engines that agree on "finding: yes" while disagreeing on the share are not agreeing.
     "Tolerance" is sized to the arithmetic, not fixed (v6, defect 9): two correct engines that
     add the same n numbers in a different order differ by roughly sqrt(n) * eps * sum|x|. v5 held
     every field to 1e-9 of ITSELF, so a total that nearly cancels (-11.5 out of a sum|x| of
     202,164 at 24M rows) failed correct engines on ordinary rounding. Integers and verdicts
     (n, k, sign flips, the finding) are still compared exactly.
  3. **Ties are dropped by position, not by value.** "Remove the top k" must remove exactly k rows
     even when the largest value appears many times. Removing every duplicate instead silently
     changes n, and results that move when ties are broken differently are the subject of case
     study 1 -- this toolkit does not get to make that mistake in its own plumbing.
  4. **Memory does not scale the way loading does.** Measured as peak RSS of each engine at two
     file sizes, reported as **MB of RSS per MB of file**. The streaming path is not flat -- the
     "drop top k" queries sort, and duckdb spills to disk (see `fcdata.py`) -- so the honest gate
     is the *rate*, not the absolute. A change that quietly started loading the file would push
     the rate up to the in-memory path's and fail here.

    python3 selftest_ooc.py                 # the gate
    python3 selftest_ooc.py --rows 2000000  # smaller/faster while developing

**What this gate does NOT establish:** that any particular instance can handle any particular
client's data. It proves correctness and that memory does not scale with the file. The actual
ceiling is a measurement on the instance type chosen for the engagement -- see `INTAKE.md` Part B,
which requires exactly that before an L2 job is quoted.
"""
from __future__ import annotations
import argparse, json, math, os, resource, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
RTOL = 1e-9
# Rounding allowance for a sum of n terms: SUM_TOL_C * sqrt(n) * eps * sum|x|. Measured gaps between
# pandas and duckdb on the 09-23 ladder (24M-192M rows) were 0.05-0.1 of sqrt(n)*eps*sum|x|, so C=10
# leaves ~100x headroom, while one row of a real defect (|x| ~ 0.01 here) is still >100x the
# allowance at 192M rows. Mutation-tested at the v6 release: seven planted engine defects, all caught.
SUM_TOL_C = 10.0
EPS = sys.float_info.epsilon
FIXTURE_CHUNK = 4_000_000   # rows per write; the fixture is never held whole (v6, defect 11)
FIELDS = ('n', 'total', 'mean', 'sharpe', 'top1_value', 'top1_share', 'n_active', 'thin', 'finding')
DROP_FIELDS = ('k', 'total', 'mean', 'sharpe', 'sign_flips', 'share_lost')


# ---------------------------------------------------------------------------------------------
# worker: run ONE engine in ITS OWN process, so peak RSS is that engine's and nobody else's
# ---------------------------------------------------------------------------------------------
def worker(path: str, column: str, engine: str) -> int:
    sys.path.insert(0, HERE)
    import fc4_concentration as fc4
    ppy = fc4.TRADING_DAYS   # the fixture is daily crypto-like returns; stated, not defaulted
    res = fc4.analyse_ooc(path, column, ppy) if engine == 'duckdb' else \
        fc4.analyse(fc4.fcdata.load_column(path, column)[0], ppy)
    res['peak_rss_mb'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0
    print(json.dumps(res, default=float))
    return 0


def run_engine(path: str, column: str, engine: str) -> dict:
    """Run one engine. A failure is RETURNED, never raised (v6, defect 11): in v5 a pandas worker
    killed for memory aborted the whole run, so duckdb never ran at the very size where its
    result mattered. Every caller must check for 'error' before using the result."""
    p = subprocess.run([sys.executable, os.path.abspath(__file__),
                        '--worker', path, '--column', column, '--engine', engine],
                       capture_output=True, text=True, cwd=HERE)
    if p.returncode != 0:
        how = 'killed by signal %d' % -p.returncode if p.returncode < 0 else 'exit %d' % p.returncode
        return {'error': f'{engine} worker {how}: {(p.stderr or p.stdout).strip()[-400:]}'}
    return json.loads(p.stdout.strip().splitlines()[-1])


def failed(*results) -> str:
    """The first engine error among `results`, or '' if every engine produced a result."""
    return next((r['error'] for r in results if 'error' in r), '')


# ---------------------------------------------------------------------------------------------
# fixtures
# ---------------------------------------------------------------------------------------------
def make_file(path: str, rows: int, kind: str) -> None:
    """Write the fixture in chunks, so building it never needs the whole column in RAM.

    v5 built the array in memory and could not make a fixture big enough to find duckdb's
    ceiling (defect 11). The values are IDENTICAL to v5's for the same seed and size -- numpy's
    Generator continues one stream across calls -- so a v5 result can be re-checked on a v6 file.
    """
    import numpy as np, pyarrow as pa, pyarrow.parquet as pq
    if kind == 'sparse':
        # v7: in the market on 34 days of 1,856 (the 2026-10-03 rehearsal's shape). Its own seed,
        # so the other fixtures stay identical to v5/v6. Small: it tests the zero-row filter only.
        g = np.random.default_rng(20261005)
        r = np.zeros(rows)
        r[g.choice(rows, 34, replace=False)] = g.normal(0.02, 0.025, 34)
        pq.write_table(pa.table({'pnl': r}), path)
        return
    rng = np.random.default_rng(20260916)
    planted_at = rows // 3
    schema = pa.schema([('pnl', pa.float64())])
    with pq.ParquetWriter(path, schema) as w:
        for start in range(0, rows, FIXTURE_CHUNK):
            r = rng.normal(0.0, 0.01, min(FIXTURE_CHUNK, rows - start))
            if kind == 'planted' and start <= planted_at < start + r.size:
                r[planted_at - start] = 0.40 * rows / 900.0   # one print big enough to carry the result
            elif kind == 'tied' and start == 0:
                r[:64] = 0.25                                  # 64 identical values, all at the maximum
            w.write_table(pa.table({'pnl': r}, schema=schema))


# ---------------------------------------------------------------------------------------------
# comparisons
# ---------------------------------------------------------------------------------------------
EXACT = ('n', 'k', 'n_active', 'sign_flips', 'thin', 'finding')


def allowance(field: str, a: dict, b: dict, ctx: dict) -> float:
    """How far two CORRECT engines can differ on `field`, from the size of the arithmetic.

    The base is the rounding of one sum of n terms, err = C * sqrt(n) * eps * sum|x|. Each field
    gets that error carried through its own formula, so a ratio taken against a total that nearly
    cancels gets a correspondingly wider allowance -- which is exactly the case v5 got wrong.
    `ctx` carries what a drop row does not hold itself: its row count `n`, the full-sample
    `total0` that share_lost and top1_share divide by, and the calendar `ppy`.
    """
    n, total0 = max(ctx['n'], 1), ctx['total0']
    S = max(a.get('sum_abs', 0.0), b.get('sum_abs', 0.0))
    err = SUM_TOL_C * math.sqrt(n) * EPS * S
    if field == 'total':
        return err
    if field == 'mean':
        return err / n
    if field == 'sharpe':
        sd = min(a.get('sd', float('nan')), b.get('sd', float('nan')))
        if not (sd > 0):
            return 0.0
        return math.sqrt(ctx['ppy']) * (err / n) / sd + abs(a['sharpe']) * SUM_TOL_C * math.sqrt(n) * EPS
    if field == 'top1_share':
        return abs(a['top1_share']) * err / abs(total0) if total0 else 0.0
    if field == 'share_lost':
        return (err / abs(total0)) * (1.0 + abs(a['total'] / total0)) if total0 else 0.0
    return 0.0   # top1_value: no arithmetic, so only the relative tolerance applies


def close(field: str, a: dict, b: dict, ctx: dict) -> tuple[bool, float]:
    """(agree?, gap as a fraction of what is allowed). The fraction is printed so a log shows how
    near the line a pass was -- a gate that only says PASS cannot be watched drifting."""
    x, y = a[field], b[field]
    if field in EXACT or isinstance(x, bool) or isinstance(y, bool):
        return x == y, 0.0
    x, y = float(x), float(y)
    if math.isnan(x) and math.isnan(y):
        return True, 0.0
    tol = max(RTOL * max(abs(x), abs(y)), allowance(field, a, b, ctx), 1e-12)
    gap = abs(x - y)
    return gap <= tol, gap / tol


def compare(pd_res: dict, dd_res: dict) -> tuple[list[str], float]:
    """Field-for-field disagreements, and the worst gap as a fraction of its allowance."""
    bad, worst = [], 0.0
    base = {'total0': pd_res['total'], 'ppy': pd_res['periods_per_year']}
    ctx = dict(base, n=pd_res['n'])
    for f in FIELDS:
        ok, frac = close(f, pd_res, dd_res, ctx)
        worst = max(worst, frac)
        if not ok:
            bad.append(f'{f}: pandas {pd_res[f]!r} vs duckdb {dd_res[f]!r} ({frac:.1f}x allowance)')
    for i, (p, d) in enumerate(zip(pd_res['drops'], dd_res['drops'])):
        ctx = dict(base, n=pd_res['n'] - p['k'])
        for f in DROP_FIELDS:
            ok, frac = close(f, p, d, ctx)
            worst = max(worst, frac)
            if not ok:
                bad.append(f'drops[{i}].{f}: pandas {p[f]!r} vs duckdb {d[f]!r} ({frac:.1f}x allowance)')
    return bad, worst


def check(label: str, ok: bool, detail: str = '') -> bool:
    print(f"  {'PASS' if ok else 'FAIL'}  {label}{('  — ' + detail) if detail else ''}")
    return ok


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--rows', type=int, default=6_000_000)
    ap.add_argument('--worker'); ap.add_argument('--column', default='pnl'); ap.add_argument('--engine')
    a = ap.parse_args()
    if a.worker:
        return worker(a.worker, a.column, a.engine)

    try:
        import duckdb  # noqa: F401
    except ImportError:
        print('  FAIL  duckdb is not installed — this bundle pins it in requirements.txt.')
        print('        Install the pinned stack; do not edit the pins in place on an engagement box.')
        return 1

    ok = True
    with tempfile.TemporaryDirectory() as tmp:
        # ---- 1 & 2: planted defect found by both, and full field-for-field parity ----
        planted = os.path.join(tmp, 'planted.parquet')
        make_file(planted, a.rows, 'planted')
        size_mb = os.path.getsize(planted) / 1e6
        print(f'\n  fixture: {a.rows:,} rows, {size_mb:,.1f} MB parquet, one planted bad print\n')

        pd_res, dd_res = run_engine(planted, 'pnl', 'pandas'), run_engine(planted, 'pnl', 'duckdb')
        err = failed(pd_res, dd_res)
        if err:
            # Report what survived before stopping: the point of running them independently.
            for name, r in (('pandas', pd_res), ('duckdb', dd_res)):
                print(f"  {name}: " + (r['error'] if 'error' in r else
                      f"completed, finding={r['finding']}, peak RSS {r['peak_rss_mb']:,.0f} MB"))
            check('both engines complete on the planted fixture', False, err)
            print('\n  **GATE FAILED** — do not ship this bundle')
            return 1

        ok &= check('the planted row is caught by the in-memory path', pd_res['finding'])
        ok &= check('the planted row is caught by the streaming path', dd_res['finding'])
        diffs, worst = compare(pd_res, dd_res)
        ok &= check(f'both engines agree on every field ({len(FIELDS) + len(DROP_FIELDS) * 3} compared)',
                    not diffs, '; '.join(diffs[:3]) if diffs else
                    f'largest gap {worst:.3f} of its allowance')
        ok &= check('both engines agree the result is one row',
                    close('top1_share', pd_res, dd_res,
                          {'n': pd_res['n'], 'total0': pd_res['total'],
                           'ppy': pd_res['periods_per_year']})[0],
                    f"share {dd_res['top1_share'] * 100:.1f}%")

        # ---- 4: how fast does memory grow with the file? ----
        big = os.path.join(tmp, 'big.parquet')
        make_file(big, a.rows * 4, 'planted')
        big_mb = os.path.getsize(big) / 1e6
        added = big_mb - size_mb
        rates, big_err = {}, {}
        for eng, small_res in (('pandas', pd_res), ('duckdb', dd_res)):
            big_res = run_engine(big, 'pnl', eng)    # each engine runs whatever the other did
            if 'error' in big_res:
                big_err[eng] = big_res['error']
                print(f'  {eng} on the {big_mb:,.0f} MB file: {big_res["error"]}')
            else:
                rates[eng] = (big_res['peak_rss_mb'] - small_res['peak_rss_mb']) / added
                print(f'  {eng} on the {big_mb:,.0f} MB file: peak RSS {big_res["peak_rss_mb"]:,.0f} MB')
        if big_err:
            ok &= check('memory grows more slowly than loading, by a clear margin', False,
                        'not measurable: ' + '; '.join(f'{e} did not complete' for e in big_err))
        else:
            ok &= check('memory grows more slowly than loading, by a clear margin',
                        rates['duckdb'] < 0.5 * rates['pandas'],
                        f"MB RSS per MB of file over {size_mb:,.0f} -> {big_mb:,.0f} MB: "
                        f"pandas {rates['pandas']:.1f}, duckdb {rates['duckdb']:.1f} "
                        f"({rates['pandas'] / rates['duckdb']:.1f}x slower growth)")

        # ---- 3: ties are dropped by position, not by value ----
        tied = os.path.join(tmp, 'tied.parquet')
        make_file(tied, min(a.rows, 500_000), 'tied')
        t_pd, t_dd = run_engine(tied, 'pnl', 'pandas'), run_engine(tied, 'pnl', 'duckdb')
        if failed(t_pd, t_dd):
            check('both engines complete on the tied fixture', False, failed(t_pd, t_dd))
            print('\n  **GATE FAILED** — do not ship this bundle')
            return 1
        n = t_dd['n']
        # 64 identical maxima: dropping the top 5 must remove 5 rows, never all 64.
        want = n - 5
        got_pd = t_pd['n'] - round(t_pd['drops'][1]['pct_of_rows'] / 100.0 * t_pd['n'])
        t_diffs = compare(t_pd, t_dd)[0]
        ok &= check('64 tied maxima: "drop top 5" removes 5 rows, not every duplicate',
                    not any(d.startswith('drops[1].total') for d in t_diffs) and got_pd == want,
                    f'n {n:,} -> {want:,}')
        ok &= check('tied fixture agrees field for field', not t_diffs, '; '.join(t_diffs[:3]))

        # ---- negative control: a clean file must NOT raise a finding on either engine ----
        clean = os.path.join(tmp, 'clean.parquet')
        make_file(clean, min(a.rows, 500_000), 'clean')
        c_pd, c_dd = run_engine(clean, 'pnl', 'pandas'), run_engine(clean, 'pnl', 'duckdb')
        if failed(c_pd, c_dd):
            check('both engines complete on the clean fixture', False, failed(c_pd, c_dd))
            print('\n  **GATE FAILED** — do not ship this bundle')
            return 1
        ok &= check('negative control: neither engine cries wolf on clean data',
                    not c_pd['finding'] and not c_dd['finding'])
        c_diffs = compare(c_pd, c_dd)[0]
        ok &= check('clean fixture agrees field for field', not c_diffs, '; '.join(c_diffs[:3]))

        # ---- v7: a mostly-zero file -- both engines must count the same non-zero rows ----
        sparse = os.path.join(tmp, 'sparse.parquet')
        make_file(sparse, 1856, 'sparse')
        s_pd, s_dd = run_engine(sparse, 'pnl', 'pandas'), run_engine(sparse, 'pnl', 'duckdb')
        if failed(s_pd, s_dd):
            check('both engines complete on the sparse fixture', False, failed(s_pd, s_dd))
            print('\n  **GATE FAILED** — do not ship this bundle')
            return 1
        ok &= check('34 active days of 1,856: both engines say THIN',
                    s_pd['thin'] and s_dd['thin'] and s_pd['n_active'] == s_dd['n_active'] == 34,
                    f"non-zero rows: pandas {s_pd['n_active']}, duckdb {s_dd['n_active']}")
        s_diffs = compare(s_pd, s_dd)[0]
        ok &= check('sparse fixture agrees field for field', not s_diffs, '; '.join(s_diffs[:3]))

    print(f"\n  {'OK — the streaming path is safe to use on an engagement' if ok else '**GATE FAILED** — do not ship this bundle'}")
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
